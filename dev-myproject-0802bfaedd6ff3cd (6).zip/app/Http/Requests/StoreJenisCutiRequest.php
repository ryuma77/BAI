<?php

namespace App\Http\Requests;

use App\Models\JenisCuti;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreJenisCutiRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('jenis_cuti_create');
    }

    public function rules()
    {
        return [
            'kode_cuti'     => [
                'string',
                'required',
                'unique:jenis_cutis',
            ],
            'jenis_cuti'    => [
                'string',
                'required',
                'unique:jenis_cutis',
            ],
            'maks_pertahun' => [
                'nullable',
                'integer',
                'min:-2147483648',
                'max:2147483647',
            ],
            'keterangan'    => [
                'string',
                'nullable',
            ],
        ];
    }
}
