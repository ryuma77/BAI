<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Resources\Json\JsonResource;

class PengajuancutiResource extends JsonResource
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
