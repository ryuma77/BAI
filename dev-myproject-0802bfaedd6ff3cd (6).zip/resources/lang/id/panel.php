<?php

return [
    'site_title' => 'MyProject',
];
